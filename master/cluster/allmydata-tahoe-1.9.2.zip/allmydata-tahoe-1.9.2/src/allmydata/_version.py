
# This _version.py is generated from darcs metadata by the tahoe setup.py
# and the "darcsver" package.

__pkgname__ = "allmydata-tahoe"
verstr = "1.9.2"
__version__ = verstr

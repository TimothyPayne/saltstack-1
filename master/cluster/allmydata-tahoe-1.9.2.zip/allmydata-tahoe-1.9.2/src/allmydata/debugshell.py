
# 'app' is overwritten by manhole when the connection is established. We set
# it to None now to keep pyflakes from complaining.
app = None


#!/usr/bin/env python

import sys
print "python%d.%d" % (sys.version_info[:2])
